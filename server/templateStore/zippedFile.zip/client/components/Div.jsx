import React from 'react';
import { Component } from 'react';

class Div extends Component {
  render() {
    return(
      <div className={this.props.className}>

      </div>
    );
  }
}

export default Div;