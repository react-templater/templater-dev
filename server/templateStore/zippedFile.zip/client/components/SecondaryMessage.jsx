import React from 'react';
import { Component } from 'react';

class SecondaryMessage extends Component {
  render() {
    return (
      <p>This is secondary message</p>
    );
  }
}

export default SecondaryMessage;