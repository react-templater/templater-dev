import React from 'react';
import { render } from 'react-dom';

render((
  <h1>Welcome to your React Templater Template</h1>
), document.getElementById('root'));
