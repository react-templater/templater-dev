import React from 'react';
import { Component } from 'react';

class Nav extends Component {
  render() {
    return (
      <div>
        <ul>
          <li>FAQ</li>
        </ul>
      </div>
    );
  }
}

export default Nav;